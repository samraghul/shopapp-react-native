const dummyData = [
    {
      id: 0,
      ownerId: "u1",
      title: "Do amet enim duis veniam proident elit",
      imageUrl: "https://via.placeholder.com/250x150.png",
      description: "Do amet enim duis veniam proident elit labore ea consequat ad irure sit ipsum nulla. Ea duis eiusmod pariatur cupidatat quis laboris velit et aute voluptate non. Tempor dolor consequat est culpa esse non voluptate commodo eu ad non. Sint quis reprehenderit deserunt exercitation amet do velit. Et dolore velit enim esse magna nisi officia et et laboris incididunt ex. Ad minim aliquip velit esse reprehenderit est esse adipisicing quis exercitation sunt mollit velit. Occaecat proident reprehenderit et consequat proident ut.",
      price: 323
    },
    {
      id: 1,
      ownerId: "u2",
      title: "Paula",
      imageUrl: "https://via.placeholder.com/250x150.png",
      description: "Ullamco nisi sint Lorem ex minim eiusmod consequat quis culpa mollit. Reprehenderit ea aute reprehenderit qui nulla. Ut reprehenderit exercitation minim consequat aute fugiat exercitation ipsum cupidatat aute labore cillum.",
      price: 355
    },
    {
      id: 2,
      ownerId: "u3",
      title: "Mays",
      imageUrl: "https://via.placeholder.com/250x150.png",
      description: "Velit occaecat proident minim laboris duis dolor tempor sit qui. Adipisicing dolore amet cillum exercitation id aute commodo id irure commodo deserunt officia et. Occaecat dolor do elit id enim excepteur mollit in magna ex voluptate excepteur pariatur. Reprehenderit fugiat pariatur officia labore eiusmod labore in. Fugiat sit labore enim nisi dolore velit occaecat. Ad esse excepteur qui est Lorem nulla consectetur deserunt.",
      price: 349
    },
    {
      id: 3,
      ownerId: "u1",
      title: "Summers",
      imageUrl: "https://via.placeholder.com/250x150.png",
      description: "Ea et nostrud deserunt magna enim cupidatat culpa veniam labore veniam cillum commodo excepteur. Anim commodo ipsum adipisicing excepteur. Qui ullamco irure mollit aliquip sit duis eu cupidatat labore minim non in. Consequat incididunt elit adipisicing laborum do proident qui nisi pariatur.",
      price: 236
    },
    {
      id: 4,
      ownerId: "u2",
      title: "Faith",
      imageUrl: "https://via.placeholder.com/250x150.png",
      description: "Irure sint sunt ipsum excepteur culpa proident ut in voluptate Lorem velit enim non. Esse adipisicing sunt ea pariatur do cupidatat ullamco sint aute ad in enim Lorem. Ipsum sit aliquip officia voluptate ea nulla officia exercitation et labore reprehenderit sint ullamco. Ea ullamco qui consequat pariatur ad anim sit voluptate id do.",
      price: 326
    },
    {
      id: 5,
      ownerId: "u3",
      title: "Alvarado",
      imageUrl: "https://via.placeholder.com/250x150.png",
      description: "Labore ipsum magna consectetur in. Est irure amet duis irure. Nulla aliqua eiusmod sunt commodo consequat adipisicing et velit. Irure commodo laboris nulla deserunt. In tempor veniam et adipisicing qui commodo est nisi dolore voluptate et. Fugiat consectetur dolor ad ex.",
      price: 266
    },
    {
      id: 6,
      ownerId: "u1",
      title: "Randi",
      imageUrl: "https://via.placeholder.com/250x150.png",
      description: "Officia adipisicing magna magna incididunt anim. Nulla reprehenderit nulla do ullamco. Amet dolor sint labore consequat cillum eu. Qui veniam consectetur amet eu esse sunt sunt tempor non. Nisi et labore sit elit id consequat eu culpa eiusmod excepteur consectetur velit. Et exercitation in laboris et nostrud nostrud tempor occaecat. Tempor enim voluptate sit laboris in voluptate deserunt sit pariatur sunt cillum culpa.",
      price: 310
    },
    {
      id: 7,
      ownerId: "u2",
      title: "Todd",
      imageUrl: "https://via.placeholder.com/250x150.png",
      description: "Enim in id ex aliqua magna commodo. Fugiat cupidatat id dolore veniam consectetur cupidatat consectetur. In dolor nostrud voluptate nostrud incididunt reprehenderit eu. Mollit Lorem in officia ea dolor eiusmod esse elit. Cillum sit quis aliquip mollit amet. Aute cupidatat ex culpa dolore. Adipisicing mollit nostrud exercitation proident voluptate veniam est laborum incididunt officia.",
      price: 305
    },
    {
      id: 8,
      ownerId: "u3",
      title: "Dalton",
      imageUrl: "https://via.placeholder.com/250x150.png",
      description: "Velit est labore est duis excepteur. In nostrud deserunt elit incididunt amet. Sint sit reprehenderit velit enim mollit tempor eiusmod adipisicing mollit. Incididunt dolore sint elit veniam consectetur aliquip. Excepteur duis ad ipsum labore aliquip ex do duis reprehenderit exercitation.",
      price: 304
    },
    {
      id: 9,
      ownerId: "u1",
      title: "Quinn",
      imageUrl: "https://via.placeholder.com/250x150.png",
      description: "Ipsum consectetur reprehenderit culpa cillum cillum cillum aliqua ipsum do dolor enim proident id labore. Excepteur qui dolore reprehenderit minim incididunt do in voluptate ullamco est est proident. Laboris Lorem incididunt consectetur quis veniam ut cillum minim eu velit.",
      price: 202
    }
  ];

  export default dummyData;