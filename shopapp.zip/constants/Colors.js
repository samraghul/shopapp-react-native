export default {
    primary: "#142F43",
    accent: "#FFAB4C"
}